<?php
require __DIR__ . '/includes/bootstrap.php';
$u = require_login();
$today = date('Y-m-d');
$todayAppts = appt_list(['from' => $today, 'to' => $today]);
$upcoming = appt_list(['from' => date('Y-m-d', strtotime('+1 day')), 'to' => date('Y-m-d', strtotime('+7 day')), 'status' => '']);
$upcoming = array_filter($upcoming, fn($a) => in_array($a['status'], ['SCHEDULED', 'CONFIRMED'], true));
[$recent] = visit_list([], 8, 0);
[, $patientTotal] = patient_search(['status' => 'active'], 1, 0);
[, $openVisits] = visit_list(['status' => 'OPEN'], 1, 0);
$cards = [['Today’s appointments', count($todayAppts), 'appointments/index.php?from=' . $today . '&to=' . $today],
          ['Next 7 days', count($upcoming), 'appointments/index.php?from=' . date('Y-m-d', strtotime('+1 day')) . '&to=' . date('Y-m-d', strtotime('+7 day'))],
          ['Open visits', $openVisits, 'visits/index.php?status=OPEN'],
          [has_role('DOCTOR') && !has_role('ADMIN') && cfg('doctor_scope') !== 'all' ? 'Patients in my care' : 'Active patients', $patientTotal, 'patients/index.php']];
if (can('admin.requests')) { $cards[] = ['Pending account requests', (int) q_val("SELECT COUNT(*) FROM account_request WHERE request_status = 'PENDING'"), 'admin/requests.php']; }
if (can('exam.write')) {
    $mine = has_role('ADMIN') ? '' : ' AND doctor_id = ' . (int) $u['doctor_id'];
    $cards[] = ['Draft examinations', (int) q_val("SELECT COUNT(*) FROM clinical_examination WHERE status = 'DRAFT'" . $mine), 'visits/index.php?status=OPEN'];
}
$stale = [];
if (can('appointment.write')) { $stale = q_all("SELECT appointment_id, appointment_no, start_at FROM appointment WHERE status IN ('SCHEDULED','CONFIRMED') AND end_at < NOW() ORDER BY start_at LIMIT 10"); }
page_start('Dashboard', ['nav' => 'dashboard', 'subtitle' => 'Signed in as ' . $u['display_name'] . ' · ' . date('l, j F Y'),
    'actions' => (can('patient.write') ? '<a class="btn btn-primary" href="' . e(url('patients/create.php')) . '">Register patient</a> ' : '') . (can('appointment.write') ? '<a class="btn btn-secondary" href="' . e(url('appointments/form.php')) . '">Book appointment</a>' : '')]);
?>
<div class="cards">
  <?php foreach ($cards as [$t, $n, $href]): ?><a class="card stat" href="<?= e(url($href)) ?>"><span class="stat-n"><?= (int) $n ?></span><span class="stat-t"><?= e($t) ?></span></a><?php endforeach; ?>
</div>
<?php if ($stale): ?>
<div class="alert alert-warn"><strong>Needs attention:</strong> <?= count($stale) ?> appointment(s) are past their time but still scheduled or confirmed (e.g. <?= e($stale[0]['appointment_no']) ?>). Mark them no-show, or open the visit, so patients can be archived later. <a href="<?= e(url('appointments/index.php?status=SCHEDULED&to=' . $today)) ?>">Review</a></div>
<?php endif; ?>
<section class="panel"><h2>Today’s appointments</h2>
  <?php if (!$todayAppts): ?><div class="empty-state small"><p>No appointments today.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table"><thead><tr><th>Time</th><th>Patient</th><th>Doctor</th><th>Reason</th><th>Status</th><th></th></tr></thead><tbody>
  <?php foreach ($todayAppts as $a): ?><tr><td><?= e(date('H:i', strtotime($a['start_at']))) ?>–<?= e(date('H:i', strtotime($a['end_at']))) ?></td>
    <td><?= can_access_patient((int) $a['patient_id']) ? '<a href="' . e(url('patients/view.php?id=' . $a['patient_id'])) . '">' . e($a['patient_name']) . '</a>' : e($a['patient_name']) ?></td>
    <td><?= e($a['doctor_name']) ?></td><td><?= e($a['reason'] ?? '') ?></td><td><?= status_badge($a['status']) ?></td>
    <td><a href="<?= e(url('appointments/view.php?id=' . $a['appointment_id'])) ?>">Details</a></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<section class="panel"><h2>Recent visits</h2>
  <?php if (!$recent): ?><div class="empty-state small"><p>No visits yet.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table"><thead><tr><th>Visit</th><th>Patient</th><th>Doctor</th><th>Type</th><th>Opened</th><th>Status</th></tr></thead><tbody>
  <?php foreach ($recent as $r): ?><tr><td><a href="<?= e(url('visits/view.php?id=' . $r['visit_id'])) ?>"><?= e($r['visit_no']) ?></a></td><td><?= e($r['patient_name']) ?></td><td><?= e($r['doctor_name']) ?></td>
    <td><?= e(label($r['visit_type'])) ?></td><td><?= e(fmt_dt($r['visited_at'])) ?></td><td><?= status_badge($r['status']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<?php page_end();
