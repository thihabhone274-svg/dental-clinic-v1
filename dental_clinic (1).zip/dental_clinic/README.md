# Dental Clinic Management System (first working version)

A server-rendered PHP + MariaDB application for a small dental clinic, built for **XAMPP on Windows**. It runs entirely on one computer with no internet connection, no Composer, no Node.js and no framework.

**Status:** first working version for clinic and teacher review. Everything described below is implemented in the code. Fields and policies that still need clinic confirmation are listed in `docs/ASSUMPTIONS_AND_FUTURE_REQUIREMENTS.md`. Read `docs/TESTING.md` for exactly what has and has not been tested.

## What it does
- **Accounts:** sign in/out, account requests with administrator approval, roles (Staff, Doctor, Administrator), activate/deactivate, change password, administrator-assisted password reset, console scripts for the first administrator and for emergency recovery.
- **Dashboard:** real counts and tables (today's and upcoming appointments, recent visits, patients, pending requests, draft examinations).
- **Patients:** directory with search and filters, registration with duplicate review (never automatic merging), profile, edit, archive (records are never deleted).
- **Medical and dental history:** versioned (every save is a new version, earlier versions are kept). Staff and administrators write; doctors are read-only. The dental questionnaire is one structured question per field.
- **Appointments:** day-grouped schedule view, booking, rescheduling (old time kept in a history table), cancelling with a reason, doctor-conflict rejection and patient-overlap warning, rechecked inside a transaction.
- **Visits:** open from an appointment or as a walk-in/emergency, close, cancel (only when no examination exists).
- **Examinations:** documented clinic-form fields plus clearly marked **provisional** sections; drafts, review, finalize, discard a draft, and **correction** of a finalized examination (the original is kept and marked superseded).
- **Audit log:** every important action, with ids and field names only (never clinical text).

## Requirements
Windows, XAMPP with **PHP 8.2** and **MariaDB 10.4** (Apache + MySQL services), PHP extensions `pdo_mysql` and `mbstring` (both enabled by default in XAMPP). The only thing the author could not test is your exact XAMPP, see `docs/TESTING.md`.

## Installation (about 10 minutes)
1. **Copy the folder.** Put the whole `dental_clinic` folder in `C:\xampp\htdocs\` so that `C:\xampp\htdocs\dental_clinic\index.php` exists.
2. **Start services.** In the XAMPP Control Panel click **Start** next to **Apache** and **MySQL**.
3. **Create the database.** Open `http://localhost/phpmyadmin`, click **Import** on the home page (do not select a database first), choose `database\dental_clinic_setup.sql` and click **Import**. It creates the database `dental_clinic` and all tables. (If you see "table already exists" the import was already done; nothing was changed.)
4. **Create the application's database user (recommended; do not run the app as root).** Open `database\optional_create_app_user.sql` in a text editor, replace `CHANGE_THIS_PASSWORD` with a long password, then paste the file into phpMyAdmin's **SQL** tab and click **Go**.
5. **Configure the connection.** Copy `config\database.example.php` to `config\database.php` and set `user` (`dental_app`) and `password` to what you chose. Keep this file private; Apache is configured not to serve it.
6. **Set your timezone.** Open `config\app.php` and change `'timezone'` to your clinic's zone ([list](https://www.php.net/manual/en/timezones.php)). The shipped value `Asia/Yangon` is only a placeholder. Times are stored and shown in this zone.
7. **Check the installation.** Open Command Prompt and run:
   `C:\xampp\php\php.exe C:\xampp\htdocs\dental_clinic\scripts\check_setup.php`
   Fix anything marked `[FAIL]`. (Before step 8 the only expected failure is "An administrator exists"; `[WARN]` about root is fine until step 4 is done.)
8. **Create the first administrator** (one time):
   `C:\xampp\php\php.exe C:\xampp\htdocs\dental_clinic\scripts\create_first_admin.php`
   Type a username, display name and password (the password is hidden). The script refuses to run again if an administrator exists, and cannot be run from a browser.
9. **Sign in** at `http://localhost/dental_clinic/`.
10. **Add staff and doctors.** Each person uses **Request an account** on the sign-in page (you can fill it in for them while signed out); you then approve it under **Account requests**. A person is either Staff or Doctor, never both. Roles are managed under **Accounts and roles**.

## Day-to-day use
| Role | Typical work |
|---|---|
| **Staff** | Register patients, record medical and dental history, book/reschedule/cancel appointments, open visits (including walk-ins), close visits. |
| **Doctor** | See own schedule and patients in active care, read histories (read-only), enter, finalize and correct examinations for their own visits. |
| **Administrator** | Everything staff and doctors can do (the real person who acted is always recorded), plus account requests, accounts and roles, and the audit log. |

A normal visit: staff register the patient and record histories, book an appointment, then on the day open the visit from the appointment page (or open a walk-in); the doctor starts the examination, saves a draft, reviews and finalizes it; the visit is then closed.

**Forgotten password:** an administrator uses **Reset password** on Accounts and roles, gives the user the one-time temporary password in person, and the user must choose a new one at sign-in.
**No administrator can sign in:** on this computer run `scripts\recover_admin.php` (needs the typed confirmation `RECOVER ADMIN`; it is audited). Keep **two** administrator accounts to avoid this.

## Configuration
- `config/app.php`: timezone, `doctor_scope` (`strict` = doctors see only patients in active care; `all` = every patient), session timeout, password length, page size, sign-in throttle.
- `config/clinic_options.php`: the examination code options, the provisional examination fields, the dental questionnaire wording, and reason lists. **Edit this file to revise labels or add/remove provisional fields without changing the database.**

## Backups
Export the `dental_clinic` database from phpMyAdmin (Export tab) regularly, or run
`C:\xampp\mysql\bin\mysqldump.exe -u root -p dental_clinic > backup.sql`. Store copies off this computer. To restore, import into an empty database. There is no hard delete anywhere in the application, so the database grows steadily; that is intentional.

## Folder structure
`index.php` dashboard · `login.php` `logout.php` `request_account.php` · `auth/` password change · `patients/` · `histories/` · `appointments/` · `visits/` · `examinations/` · `admin/` requests, accounts, audit · `includes/` shared code (authorization in `auth.php`, business rules in the `*.php` services) · `config/` · `database/` setup SQL · `scripts/` console tools · `tests/` automated tests · `assets/` CSS and JavaScript · `docs/` · `storage/logs/` error log.

## Troubleshooting
- **"Something went wrong" page:** the technical detail is in `storage\logs\php_errors.log`; the page shows a reference number that appears in the log.
- **Cannot connect to the database:** run `scripts\check_setup.php`; check `config\database.php`, that MySQL is started, and that you imported the setup SQL.
- **`Access denied for user 'dental_app'` (error 1045):** the user does not exist in the running MariaDB, or its password differs from `config\database.php`. Run `database\optional_create_app_user.sql` again with the password you put in `database.php` (it resets the password every time), then re-run `scripts\check_setup.php`. Common causes: the file was run with the default `CHANGE_THIS_PASSWORD`, the password in `database.php` has a typo or a symbol such as `'` or `\`, or the user was created before the MariaDB data folder was replaced.
- **Page not found or links go to the wrong place:** the folder must be named `dental_clinic` inside `htdocs`, or set `base_path` in `config/app.php`.
- **403 page:** your role does not allow that action; this is recorded in the audit log.
- **Times are off by hours:** fix `timezone` in `config/app.php`.

## Security notes
Passwords are hashed (bcrypt via `password_hash`); every form has a CSRF token; all database access uses prepared statements; output is escaped; the session id changes at sign-in; role checks are done on the server for every action; the configuration, includes, database, scripts, tests, docs and storage folders are blocked from the browser by `.htaccess`. Anyone with direct database access (for example a phpMyAdmin login) bypasses the application's rules; protect the MySQL `root` account with a password.
