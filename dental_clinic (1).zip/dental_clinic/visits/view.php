<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = require_can('visit.view');
$id = get_int('id'); $v = visit_find($id);
if (!$v) { abort(404, 'Not found', 'That visit does not exist.'); }
if (!can_access_visit($v)) { deny('You can open only visits where you are the responsible doctor.'); }
$exams = exams_for_visit($id); $cur = exam_current($id);
$open = $v['status'] === 'OPEN'; $canWrite = can('exam.write') && can_write_exam($v);
$med = can_access_patient((int) $v['patient_id']) ? med_latest((int) $v['patient_id']) : null;
$draft = $cur && $cur['status'] === 'DRAFT';
page_start('Visit ' . $v['visit_no'], ['nav' => 'visits', 'crumbs' => [['Visits', 'visits/index.php']], 'subtitle' => $v['patient_name'] . ' · ' . $v['patient_code'] . ' · ' . $v['doctor_name'],
    'actions' => status_badge($v['status'])]);
if ($med && $med['allergies']): ?><div class="alert alert-warn"><strong>Allergies on record:</strong> <?= e(implode(', ', array_map(fn($a) => $a['allergen_name'] . ' (' . strtolower($a['severity']) . ')', $med['allergies']))) ?>. <a href="<?= e(url('histories/medical.php?patient_id=' . $v['patient_id'])) ?>">Medical history</a></div><?php endif; ?>
<div class="grid-main-side">
<section class="panel"><h2>Visit details</h2><dl class="dl">
<?= dl_row('Patient', $v['patient_name']) ?><?= dl_row('Responsible doctor', $v['doctor_name']) ?><?= dl_row('Type', label($v['visit_type']) . ($v['appointment_no'] ? ' (appointment ' . $v['appointment_no'] . ')' : '')) ?>
<?= dl_row('Opened', fmt_dt($v['visited_at'])) ?><?= dl_row('Reception note', $v['note'], true) ?><?php if ($v['status'] === 'CLOSED'): ?><?= dl_row('Closed', fmt_dt($v['closed_at'])) ?><?php endif; ?>
<?php if ($v['status'] === 'CANCELLED'): ?><?= dl_row('Cancelled', fmt_dt($v['cancelled_at'])) ?><?= dl_row('Reason', clinic('visit_cancel_reasons')[$v['cancel_reason_code']] ?? $v['cancel_reason_code']) ?><?php endif; ?></dl>
<?php if (can_access_patient((int) $v['patient_id'])): ?><p><a href="<?= e(url('patients/view.php?id=' . $v['patient_id'])) ?>">Patient profile</a></p><?php endif; ?></section>
<aside class="panel"><h3>Visit actions</h3>
<?php if ($open): ?>
  <?php if ($draft): ?><div class="alert alert-warn">A draft examination exists. The visit cannot be closed until it is finalized or discarded.</div><?php endif; ?>
  <?php if (can('visit.close') && can_close_visit($v)): ?>
   <?= post_button('visits/close.php', ['id' => $id], 'Close visit', 'btn-primary', 'Close this visit? A linked appointment will be marked completed.') ?>
   <details class="drop"><summary class="btn btn-danger btn-sm">Cancel visit…</summary><form method="post" action="<?= e(url('visits/cancel.php')) ?>" class="drop-body" data-confirm="Cancel this visit? This is only for visits opened by mistake and without an examination.">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $id ?>"><?= f_select('reason_code', 'Reason', clinic('visit_cancel_reasons'), [], [], ['required' => true, 'placeholder' => 'Choose a reason']) ?><button class="btn btn-danger btn-sm">Cancel visit</button></form></details>
  <?php endif; ?>
<?php else: ?><p class="muted">This visit is <?= e(strtolower($v['status'])) ?>. <?= $v['status'] === 'CLOSED' ? 'Finalized examinations can still be corrected by the responsible doctor.' : '' ?></p><?php endif; ?></aside></div>
<section class="panel"><div class="row-between"><h2>Examinations</h2>
<?php if ($canWrite && $open && !$cur): ?><a class="btn btn-primary" href="<?= e(url('examinations/form.php?visit_id=' . $id)) ?>">Start examination</a><?php endif; ?>
<?php if ($canWrite && $open && $draft): ?><a class="btn btn-primary" href="<?= e(url('examinations/form.php?id=' . $cur['exam_id'])) ?>">Continue draft</a><?php endif; ?></div>
<?php if (!$exams): ?><div class="empty-state small"><p>No examination recorded for this visit yet.<?= $canWrite && $open ? '' : ' Examinations are entered by the responsible doctor or an administrator.' ?></p></div><?php else: ?>
<div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Examined</th><th>Entered by</th><th>Status</th><th>Notes</th><th></th></tr></thead><tbody>
<?php foreach ($exams as $x): ?><tr><td><?= (int) $x['exam_id'] ?></td><td><?= e(fmt_dt($x['examined_at'])) ?></td><td><?= e($x['author_name']) ?></td><td><?= status_badge($x['status']) ?></td>
<td class="muted"><?= $x['supersedes_exam_id'] ? 'Correction of #' . (int) $x['supersedes_exam_id'] : '' ?><?= $x['status'] === 'SUPERSEDED' ? 'Replaced by a correction' : '' ?></td><td><a href="<?= e(url('examinations/view.php?id=' . $x['exam_id'])) ?>">View</a></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<?php
$prev = array_values(array_filter(exams_for_patient((int) $v['patient_id'], (!has_role('ADMIN') && !has_role('STAFF') && cfg('doctor_scope') !== 'all') ? (int) $u['doctor_id'] : null), fn($x) => (int) $x['visit_id'] !== $id && $x['status'] === 'FINALIZED'));
if ($prev): ?>
<section class="panel"><h2>Previous examinations</h2><p class="muted">Finalized examinations from this patient's other visits.</p>
<div class="table-wrap"><table class="table"><thead><tr><th>Examined</th><th>Visit</th><th>Doctor</th><th></th></tr></thead><tbody>
<?php foreach ($prev as $x): ?><tr><td><?= e(fmt_dt($x['examined_at'])) ?></td><td><?= e($x['visit_no']) ?></td><td><?= e($x['doctor_name']) ?></td><td><a href="<?= e(url('examinations/view.php?id=' . $x['exam_id'])) ?>">View</a></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php endif; page_end();
